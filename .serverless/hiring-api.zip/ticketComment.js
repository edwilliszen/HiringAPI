'use strict';

const common = require('./common');
//const user = require('./user');
const ticketM = require('./ticket');

const comprehend = require('./comprehend');

const logging = common.logging;
const no_logging = common.no_logging;

const my_dynamodb = require('./dynamodb');
const dynamodb = my_dynamodb.dynamodb;

const dyn_table = common.settings.dyn_table;

//import { Configuration, OpenAIApi } from "openai";
const openai_pkg = require("openai");
const configuration = new openai_pkg.Configuration({
    organization: "org-qaGSvqbC3JxLGVFY0MPl1WMt",
    apiKey: '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',
});
const openai = new openai_pkg.OpenAIApi(configuration);

module.exports.ticketCommentEventHandler = async event => { 
    const functionName = "ticketCommentEventHandler";
    const Logging = logging;
    if (Logging) console.info(`${functionName}() - Input Event: ${JSON.stringify(event, null, 2)}`);

    if (!event) return common.build_response(functionName, 400, `Missing event`); 
    if (!event["detail-type"]) return common.build_response(functionName, 400, `Missing event.detail-type`); 

    if (Logging) console.info(`${functionName}() - event.detail-type: ${event["detail-type"]}`);

    if (!event.detail) return common.build_response(functionName, 400, `Missing event.detail`);     
    if (!event.detail.ticket_event) return common.build_response(functionName, 400, `Missing event.detail.ticket_event`); 
    if (!event.detail.ticket_event.ticket) return common.build_response(functionName, 400, `Missing event.detail.ticket_event.ticket`); 
    if (!event.detail.ticket_event.ticket.updated_at) return common.build_response(functionName, 400, `Missing event.detail.ticket_event.ticket.updated_at`); 

    const updated_at = event.detail.ticket_event.ticket.updated_at;
    var comment = event.detail.ticket_event.comment;
    const ticket = event.detail.ticket_event.ticket;
    const ticket_id = ticket.id;    // these get deleted later from the parent object
    var comment_id = 0;  // these get deleted later from the parent object  

    var sentiment = null;
    var entities = null; 
    var language = null;   
    var summary = null;

    const detail_type = event["detail-type"];

    switch (detail_type) {
        case 'Support Ticket: Comment Created':    
            comment_id = comment.id;
            const request = {
                ticketId: ticket_id,
                commentId: comment_id,
                comment: comment,
                updatedAt: updated_at
            }
            if (Logging) console.info(`${functionName}() - request: ${JSON.stringify(request, null, 2)}`);

            sentiment = await module.exports.handleSentiment(comment, detail_type, logging); 
            //const sentimentScore = comprehend.calcSentimentScore(sentiment);        
            //entities = await module.exports.handleEntities(comment, detail_type, logging);
            entities = await module.exports.handleKeywords(comment, detail_type, logging);
            summary = await module.exports.handleSummary(comment, detail_type, logging);
            //language = await module.exports.handleTranslation(ticket, comment, detail_type, logging);

            // If a public comment from requester
            if (comment.is_public) {// && comment.author.id == ticket.requester_id) { // Public Comment from Requester
                var ticketSM = {};  // for updating ticket SM small
                
                const firstTicketComment = await module.exports.isFirstTicketComment(ticket_id, logging);
                if (Logging) console.log(`${functionName} firstTicketComment: ${firstTicketComment}`);
                if (firstTicketComment) {
                    // Add requester created sentiment this will create a shell in the ticket or just update the starting value                  
                    ticketSM.requester_created_sentiment = sentiment.Sentiment                                
                    
                    // add Sentiment Tag to Ticket
                    var tags = [];
                    var tag = "requester_created_sentiment_" + sentiment.Sentiment;
                    tags.push(tag);
                    const results = await ticketM.zendeskAddTagsToTicket(ticket_id, tags, logging);
                    if (Logging) console.log(`${functionName}(): zendesk add tags ${JSON.stringify(tags, null, 2)} results: ${JSON.stringify(results, null, 2)}`);           
                }

                // Add latest user sentiment to Ticket
                ticketSM.requester_final_sentiment = sentiment.Sentiment;
                // This is for solving later to make it easy to find the last user sentiment

                if (Logging) console.log(`${functionName} ticketSM: ${JSON.stringify(ticketSM, null, 2)}`);
                const ticketResults = await ticketM.updateTicket(ticket.id, ticketSM, no_logging);  
                if (Logging) console.log(`${functionName} ticketResults: ${JSON.stringify(ticketResults, null, 2)}`);     
            }         

            const results = await module.exports.updateTicketComment(comment_id, comment, ticket_id, ticket.updated_at, sentiment, entities, language, summary, no_logging);
            if (Logging) console.info(`${functionName}() - updateTicketComment results: ${JSON.stringify(results, null, 2)}`);
            break;

        default: 
            // Not an event we are handling yet
            return common.build_response(functionName, 204, `Unhandled event = ${detail_type}`, false);
    }

    //return common.build_response(functionName, 200, ${JSON.stringify("200 - ok", null, 2)}, true);  
}

module.exports.isFirstTicketComment = async (ticketID, commentID, logResult = false) => {
    const functionName = "isFirstTicketComment";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}(): ticketID = ${ticketID}\nCommentID:${commentID}`);


    const ticketExists = await ticketM.ticketExists(ticketID, no_logging);
    if (Logging) console.info(`${functionName}(): ticket ID ${ticketID} ticketExists = ${ticketExists}`);
    
    if (ticketExists) {
        // Check to see if value of first sentiment exists
        const ticket_info = await ticketM.getTicketByID(ticketID, no_logging);
        if (Logging) console.info(`${functionName}: ticketID: ${ticketID} details ${JSON.stringify(ticket_info, null, 2)}`);
        // TODO This not right we need a better way, this is a HACK
        if (ticket_info.requester_created_sentiment) return false; // This value will exist
        else return true;
    } else return true; // Since we will write sentiment to the ticket when it exist assume true TODO this might not always work should be atomic
}


module.exports.updateTicketComment = async (CommentID, CommentAttributes, TicketID, created_at = new Date(Date.now()).toISOString(), Sentiment = null, Entities = null, Language = null, Summary = null, logResult = false) => {
    const functionName = "updateTicketComment";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}(${CommentID}), CommentAttributes: ${JSON.stringify(CommentAttributes, null, 2)}\n${TicketID}), created_at: ${created_at}\nSentiment: ${JSON.stringify(Sentiment, null, 2)}\nEntities: ${JSON.stringify(Entities, null, 2)}\nLanguage: ${JSON.stringify(Language, null, 2)}`);

    // Order of operations
    // First Write the comment, PK = comment-123, SK = comment-123 -- this is the only operation done here
    // Second Write the ticket as a child of the comment, PK = comment-123, SK = ticket-123 -- handled by trigger
    // Third Write the comment as the child of the ticket, PK = ticket-123, SK = comment-123 -- handled by trigger

    var comment_attributes = CommentAttributes;
    delete comment_attributes.id;    // dont pass the id already have it
    comment_attributes[common.table_keys.SSK] = common.table_entity.updated_at + created_at.toString();

    // Add the ticketID into the comment attributes for reference in case we need it
    comment_attributes["ticket_id"] = TicketID;
    if (Sentiment) {
        // Add overall Sentiment as a tag later
        comment_attributes['Sentiment'] = Sentiment.Sentiment;
        comment_attributes['SentimentScore'] = Sentiment.SentimentScore;
    }

    if (Entities) comment_attributes['Entities'] = Entities;

    if (Language) comment_attributes['Language'] = Language;

    if (Summary) comment_attributes['bodySummary'] = Summary;
    
    // #1 - Comment/Comment
    const paramsComment = {
        tableName: dyn_table,
        pkName: common.table_keys.PK,
        pkValue: common.table_entity.ticketComment + CommentID.toString(),
        skName: common.table_keys.SK,
        skValue: common.table_entity.ticketComment + CommentID.toString(),
        attributes: comment_attributes
    }
    if (Logging) console.info(`${functionName} paramsComment: ${JSON.stringify(paramsComment, null, 2)}`);
    const resultsComment = await my_dynamodb.updateItem (paramsComment.tableName, paramsComment.pkName, paramsComment.pkValue, 
        paramsComment.attributes, paramsComment.skName, paramsComment.skValue, no_logging);
    if (Logging) console.info(`${functionName} resultsComment: ${JSON.stringify(resultsComment, null, 2)}`);

    // Let the stream function trigger write the ticket, comment

    const results = {
        Comment: resultsComment
    }
    return results;    
}

module.exports.handleSentiment = async (comment, detail_type = 'Support Ticket: Comment Created', logResult = false) => {
    const functionName = "handleSentiment";
    const Logging = logResult;
    //if (Logging) console.info(`${functionName}(): comment = ${JSON.stringify(comment, null, 2)}\ndetail_type:${detail_type}`);

    var sentiment = null;
    if (detail_type == 'Support Ticket: Comment Created') {   // skip if not created
        sentiment = await comprehend.getSentiment(comment.body, no_logging);
        if (Logging) console.log (`${functionName}() - sentiment: ${JSON.stringify(sentiment, null, 2)}`);
    }

    return sentiment;
}

module.exports.handleEntities = async (comment, detail_type = 'Support Ticket: Comment Created', logResult = false) => {
    const functionName = "handleEntities";
    const Logging = logResult;
    //if (Logging) console.info(`${functionName}(): comment = ${JSON.stringify(comment, null, 2)}\ndetail_type:${detail_type}`);

    var entities = null; 
    if (detail_type == 'Support Ticket: Comment Created') {    // skip if not created
        entities = await comprehend.getEntities(comment.body, no_logging);    
        if (Logging) console.log (`${functionName}() - entities: ${JSON.stringify(entities, null, 2)}`);

        entities = comprehend.parseEntities(entities, no_logging);
        if (Logging) console.log (`${functionName}() - parsed entities: ${JSON.stringify(entities, null, 2)}`);                
    }

    return entities;
}

module.exports.handleKeywords = async (comment, detail_type = 'Support Ticket: Comment Created', logResult = false) => {
    const functionName = "handleSummary";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}(): comment = ${JSON.stringify(comment, null, 2)}\ndetail_type:${detail_type}`);
    if (!comment.body) {
        console.error(`ERROR! ${functionName}(): missing comment.body - ${JSON.stringify(comment, null, 2)}`);
        return null;
    }
    var keywords = comment.body; // Default to comment.body
    var text_to_keyword = common.replaceAll(keywords, "\n", " ");   // \n throws off the api call since its looking at a double return to stop parseing text    
    
    text_to_keyword = "Provide one to three keywords of the following text:\n" + text_to_keyword + "\n\n";    // add Tl;dr to get summary
    if (Logging) console.info(`${functionName}(): text_to_keyword \"${text_to_keyword}\"`); // Circular res so just pipe to logs     

    if (detail_type == 'Support Ticket: Comment Created') {    // skip if not created
        const openai_res = await openai.createCompletion({  // https://platform.openai.com/docs/api-reference/completions/create
            model: "text-davinci-003",  // https://platform.openai.com/docs/models/overview           
            prompt: text_to_keyword,
            temperature: 0.7, // sampling temperature between 0 and 2. Higher values like 0.8 = more random, lower values like 0.2 = deterministic.
            max_tokens: 60, // default to 16
            //top_p: 1.0, // defaults to 1
            //frequency_penalty: 0.0, // defaults to 0.
            presence_penalty: 1,    // > 0 talks about new topics           
        });
      
        if (Logging) console.info(`${functionName}(): openai_res.data ${common.jsonStringify(openai_res.data)}`); // Circular res so just pipe to logs               
           

        if (openai_res && openai_res.data && openai_res.data.choices[0] && openai_res.data.choices[0].text) {            
            keywords = openai_res.data.choices[0].text; 
            //if (Logging) console.info(`${functionName}(): keywords raw \"${keywords}\"`); // Circular res so just pipe to logs                   
            if (keywords.startsWith(": ") ) keywords = keywords.substring(2); // first 2 characters are ": "
            if (keywords.startsWith("\n") ) keywords = keywords.substring(1); // sometimes starts with \n
            keywords = common.replaceAll(keywords, "\"", ""); // get rid of any quotes            
            keywords = common.replaceAll(keywords, ", ", ",");  // remove trailing space after comma
            keywords = common.replaceAll(keywords, "\n", ",");  // sometimes has returns replace with comma so we can split into array
            keywords = common.replaceAll(keywords, "1. ", "");  // remove bullets
            keywords = common.replaceAll(keywords, "2. ", "");  // remove bullets
            keywords = common.replaceAll(keywords, "3. ", "");  // remove bullets
            // Remove stop words - ok
            //if (Logging) console.info(`${functionName}(): keywords comma-delimited \"${keywords}\"`); // Circular res so just pipe to logs                   
            // split comma delimited list into array
            keywords = keywords.split(",");
        }

        if (Logging) console.info(`${functionName}(): keywords array \"${JSON.stringify(keywords, null, 2)}\"`); // Circular res so just pipe to logs               
    }

    return keywords;
}

module.exports.handleSummary = async (comment, detail_type = 'Support Ticket: Comment Created', logResult = false) => {
    const functionName = "handleSummary";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}(): comment = ${JSON.stringify(comment, null, 2)}\ndetail_type:${detail_type}`);
    if (!comment.body) {
        console.error(`ERROR! ${functionName}(): missing comment.body - ${JSON.stringify(comment, null, 2)}`);
        return null;
    }
    var summary = comment.body; // Default to comment.body
    var text_to_summarize = common.replaceAll(summary, "\n", " ");   // \n throws off the api call since its looking at a double return to stop parseing text    
    //text_to_summarize = text_to_summarize + "\n\nTl;dr";    // add Tl;dr to get summary
    text_to_summarize = "Summarize the following text into one or two sentances:\n" + comment.author.name + ": " + text_to_summarize + "\n\n";    // add Tl;dr to get summary
    //text_to_summarize = "Provide one to three keywords of the following text:\n" + text_to_summarize + "\n\n";    // add Tl;dr to get summary
    if (Logging) console.info(`${functionName}(): text_to_summarize \"${text_to_summarize}\"`); // Circular res so just pipe to logs     

    if (detail_type == 'Support Ticket: Comment Created') {    // skip if not created
        const openai_res = await openai.createCompletion({  // https://platform.openai.com/docs/api-reference/completions/create
            model: "text-davinci-003",  // https://platform.openai.com/docs/models/overview           
            prompt: text_to_summarize,// + "\n\nTl;dr", // https://platform.openai.com/examples            
            temperature: 0.7, // sampling temperature between 0 and 2. Higher values like 0.8 = more random, lower values like 0.2 = deterministic.
            max_tokens: 60, // default to 16
            //top_p: 1.0, // defaults to 1
            //frequency_penalty: 0.0, // defaults to 0.
            presence_penalty: 1,    // > 0 talks about new topics           
        });

        // https://platform.openai.com/examples/default-keywords
        /*const openai_res = await openai.createCompletion({  // https://platform.openai.com/docs/api-reference/completions/create
            model: "text-davinci-003",  // https://platform.openai.com/docs/models/overview           
            prompt: text_to_summarize,// + "\n\nTl;dr", // https://platform.openai.com/examples            
            temperature: 0.5, // sampling temperature between 0 and 2. Higher values like 0.8 = more random, lower values like 0.2 = deterministic.
            max_tokens: 60, // default to 16
            top_p: 1.0, // defaults to 1
            frequency_penalty: 0.8, // defaults to 0.
            presence_penalty: 0.0,    // > 0 talks about new topics           
        });*/

        if (Logging) console.info(`${functionName}(): openai_res.data ${common.jsonStringify(openai_res.data)}`); // Circular res so just pipe to logs               
           

        if (openai_res && openai_res.data && openai_res.data.choices[0] && openai_res.data.choices[0].text) {            
            summary = openai_res.data.choices[0].text; 
            if (summary.startsWith(": ") ) summary = summary.substring(2); // first 2 characters are ": "
            if (summary.startsWith("\n") ) summary = summary.substring(1); // sometimes starts with \n
        }

        if (Logging) console.info(`${functionName}(): summary \"${summary}\"`); // Circular res so just pipe to logs               
    }

    return summary;
}


module.exports.getTicketComment = async event => {
    const functionName = "getTicketComment";
    const Logging = logging;
    if (Logging) console.info(`${functionName}(): event = ${JSON.stringify(event, null, 2)}`);
     
    if (!event || !event.queryStringParameters || !event.queryStringParameters.id) { // No Parameters so show last hour for all User groups
        const message = {
            error: 'missing QueryString and/or QueryString.id'
        };
        console.error(`${functionName} - ${message}`);        
        return common.build_response(functionName, 400, message, common.cors); 
    }

    const ticketCommentID = Number(event.queryStringParameters.id);
    if (Logging) console.info(`${functionName}() - ticketCommentId ${ticketCommentID}`);
        
    if (!ticketCommentID || ticketCommentID == "" || ticketCommentID < 0) {
        const message = `(ticketCommentID = ${ticketCommentID} - bad ticketCommentID`
        console.error(`${functionName} - ${message}`);
        return common.build_response(functionName, 400, message, common.cors);         
    }    

    const keys = {
        PK_name: common.table_keys.PK,
        PK_value: `${common.table_entity.ticketComment}${ticketCommentID}`,
        SK_name: "",
        SK_value: ""   // we want all entities
    }
    const index = null;
    
    // Now build the user list of rows
    const queryResults = await my_dynamodb.queryDynamoDB(dyn_table, index, keys.PK_name, keys.PK_value);
    if (Logging) console.info(`${functionName}(ticketCommentID = ${ticketCommentID}) queryResults = ${JSON.stringify(queryResults, null, 2)}`)
    
    //console.log(`!!! - results: ${JSON.stringify(results, null, 2)}`);
    if (queryResults && queryResults.Items && queryResults.Items.length > 0) {
        // Sort results by key
        var sorted_results = {};
        sorted_results.ticket = {};
        sorted_results.attachments = [];
        var ticket = {};
        //var comment = {};
        var attachments = [];

        for (const item of queryResults.Items) {
            var sorted = common.sortObject(item);
            if (sorted[common.table_keys.SK].startsWith(common.table_entity.ticket)) {// Ticket
                sorted.id = sorted[common.table_keys.SK].split(common.table_entity.ticket)[1];
                sorted = my_dynamodb.removeKeys(sorted);
                sorted = common.sortObject(sorted); // resort
                ticket = sorted; 
            } else if (sorted[common.table_keys.SK].startsWith(common.table_entity.ticketComment)) {   // Ticket Comment
                sorted_results = sorted;
                delete sorted_results.ticket_id;
                sorted_results = my_dynamodb.removeKeys(sorted_results);                
            } else if (sorted[common.table_keys.SK].startsWith(common.table_entity.ticketCommentAttachment)) {  // Ticket Comment
                sorted.id = sorted[common.table_keys.SK].split(common.table_entity.ticketCommentAttachment)[1];
                sorted = my_dynamodb.removeKeys(sorted);
                sorted = common.sortObject(sorted); // resort
                attachments.push(sorted);
            }
            // else error
        }        

        sorted_results.ticket = ticket;
        sorted_results.attachments = attachments;
        
        return common.build_response(functionName, 200, sorted_results, common.cors);
    } else {
        // Not found
        const message = {
            error: `TicketComment with id = ${ticketCommentID} - not found`
        };
        console.error(`${functionName} - ${message}`);
        return common.build_response(functionName, 404, message, common.cors);
    }    
}

module.exports.getCommentListForTicket = async (ticketID, includeDetails = false, logging = false) => {
    const functionName = "getCommentListForTicket";
    const Logging = logging;
    if (Logging) console.info(`${functionName}(): Called with Params - ticketID: ${ticketID}, includeDetails: ${includeDetails}`);
     
    if (!ticketID || ticketID <= 0) { // No Parameters so show last hour for all User groups
        const message = {
            error: 'missing ticketID'
        };
        console.error(`${functionName} - ${JSON.stringify(message, null, 2)}`);        
        return message;
    }
    const keys = {
        PK_name: common.table_keys.PK,
        PK_value: `${common.table_entity.ticket}${ticketID}`,
        SK_name: "",
        SK_value: ""   // we want all entities
    }
    const index = null;

    if (Logging) console.info(`${functionName}(): index: ${index}, keys: ${JSON.stringify(keys, null , 2)}`);
    
    // Now build the user list of rows
    const queryResults = await my_dynamodb.queryDynamoDB(dyn_table, index, keys.PK_name, keys.PK_value);
    if (Logging) console.info(`${functionName}(ticketID = ${ticketID}) queryResults = ${JSON.stringify(queryResults, null, 2)}`)
    
    //console.log(`!!! - results: ${JSON.stringify(results, null, 2)}`);
    if (queryResults && queryResults.Items && queryResults.Items.length > 0) {
        commentList = queryResults.Items.filter ( ( item ) => {
            //if (Logging) console.info(`${functionName} filter item = ${JSON.stringify(item, null, 2)}`)
            return !item[common.table_keys.SK].startsWith(common.table_entity.ticket) 
        });        

        var commentList = commentList.map (function (item) {
            if (Logging) console.info(`${functionName} map item = ${JSON.stringify(item, null, 2)}`)
            if (includeDetails) {
                var type = "Comment";
                if (item["converstation_id"]) type = "Message"
                return {
                    type: type,
                    ticket_id: item["ticket_id"],
                    converstation_id: item["converstation_id"],
                    id: item[common.table_keys.SK].split(common.table_entity.ticketComment)[1],
                    created_at: item[common.table_keys.SSK].split(common.table_entity.updated_at)[1],
                    is_public: item["is_public"],
                    author: item["author"],
                    priority: "normal", // TODO how we get this?
                    bodySummary: item["bodySummary"],  
                    body: item["body"],
                    sentiment: item["Sentiment"],
                    sentimentScore: comprehend.calcSentimentScore(item["SentimentScore"]),
                    keywords: item["Entities"]
                }
            }
            else return {
                comment_id: item[common.table_keys.SK].split(common.table_entity.ticketComment)[1]
            }
        });         
        
        return commentList;
    } else {
        // Not found
        const message = {
            error: `Ticket with id = ${ticketID} - not found`
        };
        console.error(`${functionName} - ${JSON.stringify(message, null, 2)}`);        
        return message;
    }    
}

module.exports.getCommentSentimentForTicket = async (ticketID, logging = false) => {
    const functionName = "getCommentSentimentForTicket";
    const Logging = logging;
    if (Logging) console.info(`${functionName}(): Called with Params - ticketID: ${ticketID}`);
     
    if (!ticketID || ticketID <= 0) { // No Parameters so show last hour for all User groups
        const message = {
            error: 'missing ticketID'
        };
        console.error(`${functionName} - ${JSON.stringify(message, null, 2)}`);        
        return message;
    }
    const keys = {
        PK_name: common.table_keys.PK,
        PK_value: `${common.table_entity.ticket}${ticketID}`,
        SK_name: "",
        SK_value: ""   // we want all entities
    }
    const index = null;

    if (Logging) console.info(`${functionName}(): index: ${index}, keys: ${JSON.stringify(keys, null , 2)}`);
    
    // Now build the user list of rows
    const queryResults = await my_dynamodb.queryDynamoDB(dyn_table, index, keys.PK_name, keys.PK_value);
    if (Logging) console.info(`${functionName}(ticketID = ${ticketID}) queryResults = ${JSON.stringify(queryResults, null, 2)}`)
    
    //console.log(`!!! - results: ${JSON.stringify(results, null, 2)}`);
    if (queryResults && queryResults.Items && queryResults.Items.length > 0) {
        commentList = queryResults.Items.filter ( ( item ) => {
            //if (Logging) console.info(`${functionName} filter item = ${JSON.stringify(item, null, 2)}`)
            return !item[common.table_keys.SK].startsWith(common.table_entity.ticket) 
        });        

        var commentList = commentList.map (function (item) {
            if (Logging) console.info(`${functionName} map item = ${JSON.stringify(item, null, 2)}`)
         
            var score = comprehend.calcSentimentScore(item["SentimentScore"]);          
            return {
                id: item[common.table_keys.SK].split(common.table_entity.ticketComment)[1],
                converstation_id: item["converstation_id"],                
                created_at: item[common.table_keys.SSK].split(common.table_entity.updated_at)[1],                
                text: item["Sentiment"],
                sentimentScore: score,
                bodySummary: item["bodySummary"],
                //body: item["body"]            
            }            
        });         
        
        return commentList;
    } else {
        // Not found
        const message = {
            error: `Ticket with id = ${ticketID} - not found`
        };
        console.error(`${functionName} - ${JSON.stringify(message, null, 2)}`);        
        return message;
    }    
}