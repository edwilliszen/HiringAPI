'use strict';

const common = require('./common');
//const user = require('./user');

//const faker = common.faker;

const logging = common.logging;
const no_logging = common.no_logging;

const my_dynamodb = require('./dynamodb');
const dynamodb = my_dynamodb.dynamodb;

const dyn_table = common.settings.dyn_table;

const ticket_status = {
    new: "new",
    open: "open",
    pending: "pending",
    hold: "hold",
    solved: "solved",
    closed: "closed"
};

const ticket_type = {
    problem: "problem",
    incident: "incident",
    question: "question",
    task: "task"
}

const ticket_priority = {
    urgent: "urgent",
    high: "high",
    normal: "normal",
    low: "low",
    default: "normal"
}


module.exports.getTicket = async event => {
    const functionName = "getTicket";
    const Logging = logging;
    if (Logging) console.info(`${functionName}(): event = ${JSON.stringify(event, null, 2)}`);
 
    
    var ticketID = 0;
    if (event.queryStringParameters && event.queryStringParameters.id) 
        ticketID = Number(event.queryStringParameters.id);
    if (Logging) console.info(`${functionName}() - ticketId ${ticketID}`);
        
    if (ticketID > 0) { // return details about a ticket        
        const keys = {
            PK_name: common.table_keys.PK,
            PK_value: `${common.table_entity.ticket}${ticketID}`,
            SK_name: "",
            SK_value: ""   // we want all entities
        }
        const index = null;
        
        // Now build the ticket list of rows
        const queryResults = await my_dynamodb.queryDynamoDB(dyn_table, index, keys.PK_name, keys.PK_value);
        if (Logging) console.info(`${functionName}(ticketID = ${ticketID}) queryResults = ${JSON.stringify(queryResults, null, 2)}`)

        // init
        var results = {};
        results.comments = [];
        var comments = [];
        
        if (queryResults && queryResults.Count > 0 && queryResults.Items) {
            results = queryResults.Items.map (function (Item) {   // Most likely only one item               
                if (Item[common.table_keys.SK] == keys.PK_value) {
                    // Ticket
                    // need to get all the attributes no matter what then modify on exception case so don't have to keep adding attributes
                    var ticket = Item;
                    ticket.comments = []
                    ticket.id = Item.PK.split(common.table_entity.ticket)[1];
                    ticket = my_dynamodb.removeKeys(ticket);              
                    return ticket;    // just return what we have
                } else if (Item[common.table_keys.SK].startsWith(common.table_entity.ticketComment)) {
                    // Push the comment into the comment's array
                    const comment = {
                        id: Item[common.table_keys.SK].split(common.table_entity.ticketComment)[1],
                        body: Item.body,
                        is_public: Item.is_public ? Item.is_public : false,
                        author: Item.author,
                        datetime: Item[common.table_keys.SSK].split(common.table_entity.updated_at)[1]                   
                    }
                    
                    // TODO return any children of comments?
                    // use ticket-comment-id to get children then format

                    comments.push(comment);
                    return;                
                }            
            
                // Shouldn't get here
                console.error(`${functionName} - unhandled entity ${Item[common.table_keys.SK]}`);
                return; // doesn't matter
            });
                
            // Sort Comments ASC        
            comments = comments.sort((a, b) => new Date(a.datetime) - new Date(b.datetime)); 

            // Sort results by key
            results = common.sortObject(results[0]);

            // Add sorted comments to results do after sorting the results to preserve comments order
            results.comments = comments;
            
            if (Logging) console.info(`${functionName} results = ${JSON.stringify(results, null, 2)}`)
            return common.build_response(functionName, 200, results, common.cors);
        } else {
            // Not found
            const message = {
                error: `Ticket with id = ${ticketID} - not found`
            };
            console.error(`${functionName} - ${message}`);
            return common.build_response(functionName, 404, message, common.cors);
        }    
    } else { // return a list of tickets
        const params = {
            table: dyn_table,  
            filterExpression: "begins_with (#pk, :pk) AND begins_with (#sk, :sk)",
            expressionAttributeNames: {
                '#pk': common.table_keys.PK,
                '#sk': common.table_keys.SK,
            },
            expressionAttributeValues: {
                ':pk': common.table_entity.ticket,
                ':sk': common.table_entity.ticket
            },
            attributesToGet: ""
        }        

        if (Logging) console.info(`${functionName}() - params: ${JSON.stringify(params, null, 2)}`);

        const results = await my_dynamodb.scanDynamoDB(params.table, params.filterExpression, params.expressionAttributeNames, 
            params.expressionAttributeValues, params.attributesToGet, no_logging);        
        
        // Sort results by SK        
        results.Items = results.Items.sort(function(a, b){  // Alpabetic sort
            if (a[common.table_keys.SK] < b[common.table_keys.SK]) return -1;
            if (a[common.table_keys.SK] > b[common.table_keys.SK]) return 1;
            return 0;                    
        });

        if (Logging) console.info(`${functionName}() - results: ${JSON.stringify(results, null, 2)}`);

        var tickets = {};
        tickets.tickets = [];

        if (results && results.Count > 0 && results.Items) {
            for (var i = 0; i < results.Items.length; i++) {
                const item = results.Items[i];
                if (Logging) console.log(`${functionName}() - item(${i}):\n${JSON.stringify(item, null, 2)}`);
                
                if (item[common.table_keys.SK].startsWith(common.table_entity.ticket)) {  // Campaign root
                    var a_ticket = item;
                    a_ticket.id = item[common.table_keys.PK].split(common.table_entity.ticket)[1];
                    a_ticket = my_dynamodb.removeKeys(a_ticket);
                    a_ticket = common.sortObject(a_ticket);
                    
                    tickets.tickets.push(a_ticket);
                } else console.warn (`${functionName}() - bad key (${item[common.table_keys.SK]}) in results: ${JSON.stringify(results, null, 2)}`);
            }    
        } else {
            // Not found
            const message = `no tickets`;
            console.error(`${functionName} - ${message}`);
            return common.build_response(functionName, 404, message, common.cors);
        } 

        if (Logging) console.info(`${functionName}() - tickets: ${JSON.stringify(tickets, null, 2)}`);
        // TODO paging when over 1000
        return common.build_response(functionName, 200, tickets, common.cors);
    }
}


module.exports.ticketEventHandler = async event => { 
    const functionName = "ticketEventHandler";
    const Logging = logging;
    if (Logging) console.info(`${functionName}() - Input Event: ${JSON.stringify(event, null, 2)}`);

    if (!event) return common.build_response(functionName, 400, `Missing event`); 
    if (!event["detail-type"]) return common.build_response(functionName, 400, `Missing event.detail-type`); 

    if (Logging) console.info(`${functionName}() - event.detail-type: ${event["detail-type"]}`);

    if (!event.detail) return common.build_response(functionName, 400, `Missing event.detail`);     
    if (!event.detail.ticket_event) return common.build_response(functionName, 400, `Missing event.detail.ticket_event`); 
    if (!event.detail.ticket_event.ticket) return common.build_response(functionName, 400, `Missing event.detail.ticket_event.ticket`); 
    if (!event.detail.ticket_event.ticket.updated_at) return common.build_response(functionName, 400, `Missing event.detail.ticket_event.ticket.updated_at`); 
    if (!event.detail.ticket_event.ticket.via || !event.detail.ticket_event.ticket.via.channel) return common.build_response(functionName, 400, `Missing event.detail.ticket_event.ticket.via.channel`); 
        
    //const priority = event.detail.ticket_event.ticket.priority ? event.detail.ticket_event.ticket.priority : ticket_priority.default;
    //const brand_id = event.detail.ticket_event.ticket.brand_id;
    //const group_id = event.detail.ticket_event.ticket.group_id;
    //const requester_id = event.detail.ticket_event.ticket.requester_id;
    const ticket_id = event.detail.ticket_event.ticket.id;
    
    const channel = common.decodeChannelFromEvent(event, logging);
    if (Logging) console.info(`${functionName}() - channel: ${channel}`);
     
    var ticket = buildMinimalTicketFromEvent(event);
    const detail_type = event["detail-type"];
    // trap the various events and add attributes to ticket object
    switch (detail_type) {
        case "Support Ticket: Agent Assignment Changed":            
            ticket["assignee_id"] = event.detail.ticket_event.current;  
            break;
            
        case "Support Ticket: Brand Changed":        
            ticket["brand_id"] = event.detail.ticket_event.current;
            break;
        
        case "Support Ticket: Custom Field Changed":
            // keys $.detail.ticket_event.custom_field  .id, .title, .field_type; value: $.detail.ticket_event.current
            const id = event.detail.ticket_event.custom_field.id;
            const title = event.detail.ticket_event.custom_field.raw_title;
            const field_type = event.detail.ticket_event.custom_field.field_type; 
            //const custom_field_name = `custom_field-${id}-${field_type}-${title.replace(' ', '_')}`; // type-id-title = current
            // We have more info in this event than we do for the import so use the format custom_field-id
            const custom_field_name = `custom_field-${id}`; // custom_field-id
            
            var value = event.detail.ticket_event.current;
            // convert integer and decimals to number
            if (field_type == "integer") value = Number(value);   
            else if (field_type == "decimal") value = parseFloat(value, 10);

            ticket[custom_field_name] = value;
            break;

        case "Support Ticket: Description Changed":
            ticket.description = event.detail.ticket_event.current; 
            break;

        case "Support Ticket: External ID Changed":
            ticket["external_id"] = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Email CCs Changed": // Treat like tags
        case "Support Ticket: Followers Changed": // Treat like tags
            var list_column = "";
            if (detail_type == "Support Ticket: Email CCs Changed") list_column = "email_cc";
            else if (detail_type == "Support Ticket: Followers Changed") list_column = "followers";
            else return common.build_response(functionName, 502, "Bad logic in email/follower case");

            const ticket_results = await module.exports.getTicketByID(ticket_id, no_logging);
            if (Logging) console.log(`${functionName} ticket_results: ${JSON.stringify(ticket_results, null, 2)}`);
                        
            if (ticket_results) {
                // set initial state
                var column_data = [];
                if (ticket_results[list_column]) column_data = ticket_results[list_column];
                
                // add those added                
                column_data = column_data.concat(event.detail.ticket_event.users_added).unique();

                // remove those removed
                column_data = column_data.filter( ( el ) => !event.detail.ticket_event.users_removed.includes( el ) );
                
                // Add column and data
                ticket[list_column] = column_data;

            } else {
                const message = `Could not load ticket_id: ${ticket_id}`;
                console.error (`${functionName} - ${message}`);
                return common.build_response(functionName, 502, message);
            }
           
            break;       

        case "Support Ticket: Form Changed":
            ticket["form_id"] = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Group Assignment Changed":            
            ticket["group_id"] = event.detail.ticket_event.current;            
            break;

        case "Support Ticket: Organization Changed":
            ticket["organization_id"] = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Priority Changed":
            ticket.priority = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Problem Link Changed":
            ticket["problem_link"] = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Requester Changed":
            ticket["requester_id"] = event.detail.ticket_event.current;
            ticket[common.table_keys.SSK] = event.detail.ticket_event.current;  // Must update the SSK as well since requester part of GSI1
            break;

        case "Support Ticket: Status Changed":
            ticket.status = event.detail.ticket_event.current;
            if (ticket.status == "solved") {
                // Trap Solved status and add last user sentiment tag
                const ticket_info = await module.exports.getTicketByID(ticket_id, no_logging);
                if (Logging) console.info(`${functionName}: ticket_id: ${ticket_id} details ${JSON.stringify(ticket_info, null, 2)}`);
                
                var tags = [];
                var tag = "";
            
                if (ticket_info.requester_final_sentiment) {    // If we have this info then add to ticket
                    // add Final Sentiment Tag to Ticket
                    tag = "requester_final_sentiment_" + ticket_info.requester_final_sentiment;
                    tags.push(tag);                    
                }

                // Add swing sentiment tags
                if (ticket_info.requester_created_sentiment && ticket_info.requester_final_sentiment) {
                    if (Logging) console.info(`${functionName}: ticket_info.requester_created_sentiment: ${ticket_info.requester_created_sentiment} ticket_info.requester_final_sentiment ${JSON.stringify(ticket_info.requester_final_sentiment, null, 2)}`);
                    
                    // requester_positive_to_negative   // Starts POS, End Negative
                    if (ticket_info.requester_created_sentiment == "POSITIVE" && ticket_info.requester_final_sentiment == "NEGATIVE") {
                        tag = "requester_positive_to_negative";
                        tags.push(tag);                    
                    }

                    // requester_negative_to_positive   // Starts NEG, End Pos
                    if (ticket_info.requester_created_sentiment == "NEGATIVE" && ticket_info.requester_final_sentiment == "POSITIVE") {
                        tag = "requester_negative_to_positive";
                        tags.push(tag);                    
                    }
                }               
                
                const results = await module.exports.zendeskAddTagsToTicket(ticket_id, tags, no_logging);
                if (Logging) console.log(`${functionName}(): zendesk add tags ${JSON.stringify(tags, null, 2)} results: ${JSON.stringify(results, null, 2)}`);
            }
            
            break;

        case "Support Ticket: Subject Changed":
            ticket.subject = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Submitter Changed":
            ticket["submitter_id"] = event.detail.ticket_event.current;
            break;

        case "Support Ticket: Tags Changed":
            ticket.tags = event.detail.ticket_event.ticket.tags;
            break;

        case "Support Ticket: Task Due At Changed":
            ticket["task_due_at"] = event.detail.ticket_event.current;
            break;
        
        case "Support Ticket: Ticket Created":
        case "Support Ticket: Ticket Merged":   // Treat as soft deleted
        case "Support Ticket: Ticket Soft Deleted": // treat same as created since just updating the status
        case "Support Ticket: Ticket Undeleted":  // treat same as created, and will recreate
            ticket = buildTicketFromEvent(event);   // build entire ticket out
            if (detail_type == "Support Ticket: Ticket Merged") ticket["target_ticket_id"] = event.detail.ticket_event.target_ticket_id;
            break;         
            
        case "Support Ticket: Ticket Marked as Spam":       // treat as hard delete 
        case "Support Ticket: Ticket Permanently Deleted":  // do a hard delete
            // First check the environment preference for hard deletes, if no hard deletes then treat as Soft Deleted
            if (common.preferences.hard_deletes == 'true') {      
                
                // Delete ticket - the db stream will delete the children
                const delete_results = await deleteTicket(ticket.id, no_logging);
                if (Logging) console.log(`${functionName} delete_results: ${JSON.stringify(delete_results, null, 2)}`);        

                // Done stop execution
                return common.build_response(functionName, 200, delete_results, common.no_cors);
            } else {    // treat as soft delete
                ticket = buildTicketFromEvent(event);   // build entire ticket out                
            }
            break;

        case "Support Ticket: Ticket Type Changed":
            ticket.type = event.detail.ticket_event.current;
            break;

        default: 
            // Not an event we are handling yet
            return common.build_response(functionName, 204, `Unhandled event = ${event["detail-type"]}`, common.no_cors);
    }   
    
    if (Logging) console.log(`${functionName} ticket: ${JSON.stringify(ticket, null, 2)}`);
    const results = await module.exports.updateTicket(ticket.id, ticket, no_logging);  
    if (Logging) console.log(`${functionName} results: ${JSON.stringify(results, null, 2)}`);        
   
    common.build_response(functionName, 200, results);
}


module.exports.updateTicket = async (TicketID, Attributes, logResult = false) => { 
    const functionName = "updateTicket";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}(${TicketID}), Attributes: ${JSON.stringify(Attributes, null, 2)}`);

    var ticket_attributes = Attributes;    
    delete ticket_attributes.id;    // dont pass the id already have it

    var priority = common.ticket_priority.normal;
    if (typeof ticket_attributes.priority != "undefined" && !ticket_attributes.priority === null) 
        priority = ticket_attributes.priority;  // Sometimes this comes across as null or undefined
    else priority = ticket_priority.default;

    //ticket_attributes[common.table_keys.SSK] = common.table_entity.priority + ticket_attributes.priority;
    ticket_attributes[common.table_keys.SSK] = common.table_entity.requester + ticket_attributes.requester_id;    

    const params = {
        tableName: dyn_table,
        pkName: common.table_keys.PK,
        pkValue: common.table_entity.ticket + TicketID.toString(),
        skName: common.table_keys.SK,
        skValue: common.table_entity.ticket + TicketID.toString(),
        attributes: ticket_attributes
    }
    if (Logging) console.info(`${functionName} params: ${JSON.stringify(params, null, 2)}`);

    const results = await my_dynamodb.updateItem (params.tableName, params.pkName, params.pkValue, params.attributes, 
        params.skName, params.skValue, no_logging);
    if (Logging) console.info(`${functionName} results: ${JSON.stringify(results, null, 2)}`);

    return results;
}

module.exports.getTicketByID = async function(ticket_id, logResult = false) {  
    const functionName = "getTicketByID";
    const Logging = logResult;
    if (Logging) console.info(`${functionName} - ticket_id:${ticket_id})`);
    
    const keys = {
        PK_name: common.table_keys.PK,
        PK_value: `${common.table_entity.ticket}${ticket_id}`,
        SK_name: common.table_keys.SK,
        SK_value: `${common.table_entity.ticket}${ticket_id}`
    }
    const index = null;

    if (Logging) console.info(`${functionName} keys = ${JSON.stringify(keys, null, 2)}`)

    // Now build the ticket list of rows
    const queryResults = await my_dynamodb.queryDynamoDB(dyn_table, index, keys.PK_name, keys.PK_value, keys.SK_name, keys.SK_value);
    if (Logging) console.info(`${functionName}(ticket_id = ${ticket_id}) queryResults = ${JSON.stringify(queryResults, null, 2)}`)

    if (queryResults && queryResults.Items) return queryResults.Items[0];   // Only return one
    else { 
        console.warn (`${functionName} - Ticket for ${ticket_id} not found.`);
        return null;
    }
}

module.exports.createZendeskTicket = async (requesterID, subject, description, tags = [],
    priority = ticket_priority.normal, type = ticket_type.problem, status = ticket_status.new, logResult = false) => {  
    const functionName = "createZendeskTicket";
    const Logging = logResult;

    if (Logging) console.info(`${functionName}(${requesterID}), subject: ${subject} description: ${description}, tags: ${JSON.stringify(tags, null, 2)}, priority: ${priority}, type: ${type}, status: ${status}`);

    //try {
      // https://developer.zendesk.com/rest_api/docs/support/tickets#create-ticket
      const apiPath = `/api/v2/tickets.json`;
      const method = 'POST';
      if (Logging) console.log(`${method} apiPath ${apiPath}`);
  
      const body = {
        ticket: {            
            subject: subject,
            priority: priority,
            status: status,
            type: type,
            requester_id: requesterID,
            submitter_id: 397943633111, // TODO shouldn't be hardcoded, where to get?
            tags: tags ? tags : [],
            comment: {
                body: description ? description : subject,
                public: true
            }
        }
      };  
      //if (Logging) 
      console.info(functionName + "() - body: " + JSON.stringify(body, null, 2));  

      const request_body = {
        hostname: common.settings.zendeskHost,
        path: apiPath,
        headers: {
          "Authorization": 'Basic ' + common.settings.encodedUserToken,
          //'content-length': Buffer.byteLength(body),
          "content-type": 'application/json'
        },
        body: JSON.stringify(body, null, 2)        
      };
  
      if (Logging) console.info(functionName + "() - request_body: " + JSON.stringify(request_body, null, 2));     
      const res = await common.httpsRequest(method, request_body);
      const ticket_response = JSON.parse(res.toString('utf-8'));      
      //if (Logging) 
      console.info(functionName + "() - response: " + JSON.stringify(ticket_response, null, 2));     
        
      if (res)
        return ticket_response.ticket.id;      
      else 
        return 0;
      
   /* } catch (error) {
      console.error(`${functionName}() - error: ${JSON.stringify(error, null, 2)}`);
      return false;
    }*/
}


module.exports.zendeskAddTagsToTicket = async (ticketID, tags = [], logResult = false) => {  
    const functionName = "zendeskAddTagsToTicket";
    const Logging = logResult;

    if (Logging) console.info(`${functionName}(ticketID=${ticketID}), tags: ${JSON.stringify(tags, null, 2)}`);

    if (!ticketID || ticketID < 1) {
        console.error (`${functionName}() missing ticketID`)
        return 0;
    }

    if (!tags || tags.count <= 0) {
        console.error (`${functionName}() missing tags[]`)
        return 0;
    }

    //try {
      // https://developer.zendesk.com/rest_api/docs/support/tickets#create-ticket
      const apiPath = `/api/v2/tickets/${ticketID}/tags.json`;
      const method = 'PUT';
      if (Logging) console.log(`${method} apiPath ${apiPath}`);
  
      const body = {
        tags: tags ? tags : []
      };  
      if (Logging) console.info(functionName + "() - body: " + JSON.stringify(body, null, 2));  

      const request_body = {
        hostname: common.settings.zendeskHost,
        path: apiPath,
        headers: {
          "Authorization": 'Basic ' + common.settings.encodedUserToken,          
          "content-type": 'application/json'
        },
        body: JSON.stringify(body, null, 2)        
      };
  
      if (Logging) console.info(functionName + "() - request_body: " + JSON.stringify(request_body, null, 2));     
      const res = await common.httpsRequest(method, request_body);
      const ticket_response = JSON.parse(res.toString('utf-8'));      
      if (Logging) console.info(functionName + "() - response: " + JSON.stringify(ticket_response, null, 2));     
        
      if (res)
        return 1;      
      else 
        return 0;
      
   /* } catch (error) {
      console.error(`${functionName}() - error: ${JSON.stringify(error, null, 2)}`);
      return false;
    }*/
}

module.exports.ticketExists = async function(TicketID, logResult = false) {  
    const functionName = "ticketExists";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}() - TicketID: ${TicketID})`);
    
    const params = {
        tableName: dyn_table,
        pkName: common.table_keys.PK,
        pkValue: common.table_entity.ticket + TicketID,
        skName: common.table_keys.SK,        
        skValue: common.table_entity.ticket + TicketID
    }
    if (Logging) console.info(`${functionName} params: ${JSON.stringify(params, null, 2)}`);    
    
    const results = await my_dynamodb.itemExists (params.tableName, params.pkName, params.pkValue, params.skName, params.skValue, "", no_logging);
    if (Logging) console.info(`${functionName} results: ${JSON.stringify(results, null, 2)}`);
    return results;
}

// PRIVATE

function buildMinimalTicketFromEvent(event) {
    const ticket = {
        id: event.detail.ticket_event.ticket.id,        
        updated_at: event.detail.ticket_event.ticket.updated_at,
        requester_id: event.detail.ticket_event.ticket.requester_id,
    };

    return ticket;
}

function buildTicketFromEvent(event) {
    const ticket = {
        id: event.detail.ticket_event.ticket.id,
        created_at: event.detail.ticket_event.ticket.created_at,
        updated_at: event.detail.ticket_event.ticket.updated_at,
        type: event.detail.ticket_event.ticket.type,
        priority: event.detail.ticket_event.ticket.priority ? event.detail.ticket_event.ticket.priority : ticket_priority.default,
        status: event.detail.ticket_event.ticket.status,
        requester_id: event.detail.ticket_event.ticket.requester_id,
        submitter_id: event.detail.ticket_event.ticket.submitter_id,
        assignee_id: event.detail.ticket_event.ticket.assignee_id,
        organization_id: event.detail.ticket_event.ticket.organization_id,
        group_id: event.detail.ticket_event.ticket.group_id,
        brand_id: event.detail.ticket_event.ticket.brand_id,
        form_id: event.detail.ticket_event.ticket.form_id,
        external_id: event.detail.ticket_event.ticket.external_id,
        tags: event.detail.ticket_event.ticket.tags,
        channel: event.detail.ticket_event.ticket.via.channel
    };

    return ticket;
}


const deleteTicket = async function(TicketID, logResult = false) {  
    const functionName = "deleteTicket";
    const Logging = logResult;
    if (Logging) console.info(`${functionName}() - TicketID: ${TicketID})`);
    
    const params = {
        tableName: dyn_table,
        pkName: common.table_keys.PK,
        pkValue: common.table_entity.ticket + TicketID,
        skName: common.table_keys.SK,        
        skValue: common.table_entity.ticket + TicketID
    }
    if (Logging) console.info(`${functionName} params: ${JSON.stringify(params, null, 2)}`);    
    
    const results = await my_dynamodb.deleteItem (params.tableName, params.pkName, params.pkValue, params.skName, params.skValue, no_logging);
    if (Logging) console.info(`${functionName} results: ${JSON.stringify(results, null, 2)}`);
    return results;
}
